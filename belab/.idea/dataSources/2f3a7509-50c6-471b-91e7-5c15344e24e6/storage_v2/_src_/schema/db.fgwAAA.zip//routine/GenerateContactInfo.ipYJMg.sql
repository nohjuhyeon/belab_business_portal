create
    definer = admin@`172.30.1.%` procedure GenerateContactInfo(IN num_records int)
BEGIN
    DECLARE i INT DEFAULT 0;
    DECLARE user_count INT;
    DECLARE random_user_id INT;

    -- Step 1: user 테이블의 사용자 수 계산
    SELECT COUNT(*) INTO user_count FROM user;

    -- 사용자 수가 0명일 경우 오류 발생
    IF user_count = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'No users found in the user table!';
    END IF;

    -- Step 2: contact_info_board에 데이터 삽입
    WHILE i < num_records DO
        -- 랜덤한 user_id 선택
        SELECT user_id INTO random_user_id
        FROM user
        ORDER BY RAND()
        LIMIT 1;

        -- contact_info_board에 데이터 삽입
        INSERT INTO contact_info_board (user_id, title, content, created_at, updated_at)
        VALUES (
            random_user_id, -- 랜덤 선택된 사용자 ID
            CONCAT('Notice Title ', LPAD(i + 1, 4, '0')), -- 제목
            CONCAT('This is notice content number ', i + 1, '.'), -- 내용
            NOW(), -- 생성 시간
            NOW() -- 업데이트 시간
        );

        SET i = i + 1;
    END WHILE;
END;

