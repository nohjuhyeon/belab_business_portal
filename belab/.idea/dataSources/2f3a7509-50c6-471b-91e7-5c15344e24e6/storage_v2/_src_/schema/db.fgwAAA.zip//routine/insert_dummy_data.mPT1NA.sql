create
    definer = admin@`172.30.1.%` procedure insert_dummy_data()
BEGIN
    DECLARE i INT DEFAULT 1;

    WHILE i <= 100 DO
            INSERT INTO contact_info_board (user_id, title, content, created_at, updated_at)
            VALUES (FLOOR(RAND() * 10) + 1, CONCAT('문의 ', i), CONCAT('내용 ', i), NOW(), NOW());
            SET i = i + 1;
        END WHILE;
END;

