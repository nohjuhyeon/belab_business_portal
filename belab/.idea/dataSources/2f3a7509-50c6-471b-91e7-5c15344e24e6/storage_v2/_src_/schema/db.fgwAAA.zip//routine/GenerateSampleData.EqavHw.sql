create
    definer = admin@`172.30.1.%` procedure GenerateSampleData(IN num_users int, IN num_boards int, IN num_files int)
BEGIN
    DECLARE i INT DEFAULT 0;

    -- Step 1: user 테이블에 샘플 데이터 삽입
    WHILE i < num_users DO
        INSERT IGNORE INTO user (username, password, email, affiliation, is_active, join_at, updated_at, role, hp)
        VALUES (
            CONCAT('User', i + 1), -- username
            'password123', -- password
            CONCAT('user', i + 1, '@example.com'), -- email
            'Affiliation Example', -- affiliation
            1, -- is_active
            NOW(), -- join_at
            NOW(), -- updated_at
            'user', -- role
            CONCAT('010-', LPAD(FLOOR(RAND() * 10000), 4, '0'), '-', LPAD(FLOOR(RAND() * 10000), 4, '0')) -- hp
        );
        SET i = i + 1;
    END WHILE;

    -- Step 2: reference_board 테이블에 샘플 데이터 삽입
    SET i = 0;
    WHILE i < num_boards DO
        INSERT INTO reference_board (user_id, title, content, created_at, updated_at)
        VALUES (
            FLOOR(RAND() * num_users) + 1, -- user_id (1부터 num_users까지)
            CONCAT('Sample Title ', LPAD(i + 1, 4, '0')), -- title
            CONCAT('This is sample content number ', i + 1), -- content
            NOW(), -- created_at
            NOW() -- updated_at
        );
        SET i = i + 1;
    END WHILE;

    -- Step 3: reference_file_info 테이블에 샘플 데이터 삽입
    SET i = 0;
    WHILE i < num_files DO
        INSERT INTO reference_file_info (refer_board_id, file_name, file_path, file_size, created_at, updated_at)
        VALUES (
            FLOOR(RAND() * num_boards) + 1, -- refer_board_id (1부터 num_boards까지)
            CONCAT('file_', LPAD(i + 1, 4, '0'), '.txt'), -- file_name
            CONCAT('/path/to/file_', LPAD(i + 1, 4, '0'), '.txt'), -- file_path
            FLOOR(RAND() * 1024) + 1, -- file_size (1 ~ 1024 KB)
            NOW(), -- created_at
            NOW() -- updated_at
        );
        SET i = i + 1;
    END WHILE;
END;

