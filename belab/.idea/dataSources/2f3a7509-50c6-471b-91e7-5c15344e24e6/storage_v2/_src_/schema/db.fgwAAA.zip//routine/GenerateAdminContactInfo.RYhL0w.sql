create
    definer = admin@`172.30.1.%` procedure GenerateAdminContactInfo(IN num_records int)
BEGIN
    DECLARE i INT DEFAULT 0;
    DECLARE admin_id INT;

    -- Step 1: admin 계정의 user_id 찾기
    SELECT user_id INTO admin_id 
    FROM user 
    WHERE username = 'admin';

    -- admin 계정이 존재하지 않을 경우 예외 처리
    IF admin_id IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Admin user not found!';
    END IF;

    -- Step 2: contact_info_board에 데이터 삽입
    WHILE i < num_records DO
        INSERT INTO contact_info_board (user_id, title, content, created_at, updated_at)
        VALUES (
            admin_id, -- admin 계정의 user_id
            CONCAT('Admin Notice ', LPAD(i + 1, 4, '0')), -- 제목
            CONCAT('This is admin temporary content number ', i + 1, '.'), -- 내용
            NOW(), -- 생성 시간
            NOW() -- 업데이트 시간
        );
        SET i = i + 1;
    END WHILE;
END;

