create
    definer = admin@`172.30.1.%` procedure insert_contact_info_board()
BEGIN
    DECLARE i INT DEFAULT 1;
    DECLARE max_user_id INT;
    
    -- user 테이블에서 최대 user_id 값 찾기
    SELECT MAX(user_id) INTO max_user_id FROM user;

    -- 100개의 더미 데이터 삽입
    WHILE i <= 100 DO
        INSERT INTO contact_info_board (user_id, title, content, created_at, updated_at)
        VALUES (FLOOR(1 + (RAND() * max_user_id)), 
                CONCAT('Title ', i), 
                CONCAT('Content for board ', i),
                NOW(), 
                NOW());
        SET i = i + 1;
    END WHILE;
END;

