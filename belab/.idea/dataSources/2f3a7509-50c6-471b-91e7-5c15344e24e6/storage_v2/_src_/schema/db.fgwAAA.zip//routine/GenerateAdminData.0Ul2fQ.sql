create
    definer = admin@`172.30.1.%` procedure GenerateAdminData(IN num_boards int, IN num_files int)
BEGIN
    DECLARE admin_id INT;
    DECLARE i INT DEFAULT 0;
    DECLARE j INT DEFAULT 0;

    -- Step 1: admin 계정의 user_id 찾기
    SELECT user_id INTO admin_id 
    FROM user 
    WHERE username = 'admin';

    IF admin_id IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Admin user not found!';
    END IF;

    -- Step 2: reference_board에 게시글 삽입
    WHILE i < num_boards DO
        INSERT INTO reference_board (user_id, title, content, created_at, updated_at)
        VALUES (
            admin_id,
            CONCAT('Admin Title ', LPAD(i + 1, 4, '0')),
            CONCAT('This is admin content number ', i + 1),
            NOW(),
            NOW()
        );

        -- 방금 삽입한 게시글의 ID 가져오기
        SET @board_id = LAST_INSERT_ID();

        -- Step 3: reference_file_info에 파일 삽입
        SET j = 0;
        WHILE j < num_files DO
            INSERT INTO reference_file_info (refer_board_id, file_name, file_path, file_size, created_at, updated_at)
            VALUES (
                @board_id,
                CONCAT('admin_file_', LPAD(j + 1, 4, '0'), '.txt'),
                CONCAT('/admin/files/admin_file_', LPAD(j + 1, 4, '0'), '.txt'),
                FLOOR(RAND() * 1024) + 1,
                NOW(),
                NOW()
            );
            SET j = j + 1;
        END WHILE;

        SET i = i + 1;
    END WHILE;
END;

